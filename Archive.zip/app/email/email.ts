export class Email {
    fromEmail!: string;
    recipientEmail!: string;
    attachmentFileName!: string;
    message!: string;
  }